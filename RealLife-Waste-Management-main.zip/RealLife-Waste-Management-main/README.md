# RealLife-Waste-Management
 Waste Management- Using Html , CSS , JavaScript, Python, React, NodeJs
